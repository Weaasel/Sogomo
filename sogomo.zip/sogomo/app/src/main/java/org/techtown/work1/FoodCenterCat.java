package org.techtown.work1;

public class FoodCenterCat {

    private String fc;
    private String cat;

    public FoodCenterCat(String fc, String cat) {
        this.cat = cat;
        this.fc = fc;
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat;
    }

    public String getFc() {
        return fc;
    }

    public void setFc(String fc) {
        this.fc = fc;
    }
}
