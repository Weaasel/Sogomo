package org.techtown.work1;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Documentation extends AppCompatActivity {

    ButtonFrag fragment_btn;
    Frag_J fragment_j;
    Frag_K fragment_k;
    Frag_D fragment_d;
    Frag_X fragment_x;
    Frag_T fragment_t;
    Frag_Ga fragment_ga;
    Frag_Gon fragment_gon;
    Frag_Al fragment_al;
    FragmentManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc);

        manager = getSupportFragmentManager();
        fragment_btn = new ButtonFrag();
        getSupportFragmentManager().beginTransaction().add(R.id.fragment, fragment_btn).commit();
    }

    public void ChangeFragment(int index) {

        fragment_j = new Frag_J();
        fragment_k = new Frag_K();
        fragment_d = new Frag_D();
        fragment_x = new Frag_X();
        fragment_t = new Frag_T();
        fragment_ga = new Frag_Ga();
        fragment_gon = new Frag_Gon();
        fragment_al = new Frag_Al();

        if (index == 0) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_btn).commit();
        } else if (index == 1) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_j).commit();
        } else if (index == 2) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_k).commit();
        } else if (index == 3) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_d).commit();
        } else if (index == 4) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_x).commit();
        } else if (index == 5) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_t).commit();
        } else if (index == 6) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_ga).commit();
        } else if (index == 7) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_gon).commit();
        } else if (index == 8) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment, fragment_al).commit();
        }
    }



}
