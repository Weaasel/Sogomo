package org.techtown.work1;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class FoodActivity extends AppCompatActivity {

    Button enroll, list;
    ArrayList<ListItem> tolistingklist = new ArrayList<ListItem>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        enroll = (Button) findViewById(R.id.button_enroll);
        enroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EnrollTable.class);
                startActivityForResult(intent,1000);
            }
        });
        list = (Button) findViewById(R.id.button_check);
        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), List.class);
                intent.putExtra("list",tolistingklist);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            switch(requestCode){
                case 1000 :
                    ListItem inform = (ListItem)data.getParcelableExtra("newlistinfo");
                    tolistingklist.add(0,inform);
            }
        }

    }
}
