package org.techtown.work1;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

public class ListAdapter extends BaseAdapter {
    ArrayList<ListItem> items = new ArrayList<ListItem>();

    public void addItem(ListItem item) {
        items.add(item);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Context context = parent.getContext();
        final ListItemView view = new ListItemView(context);
        final ListItem item = items.get(position);
        view.setFood(item.getFood());
        view.setTime(item.getTime());
        view.setWater(item.getWater());
        view.setWriter(item.getManager());
        view.setWeather(item.getWeather());
        view.setDay(item.getDay());
        view.settext(item.getNote());
        view.setId(item.getIdnum());
        view.setFc(item.getFc());


        return view;
    }
}