package org.techtown.work1;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class InputAct extends AppCompatActivity {
    String img1;
    String img2;
    String img3;
    String imgUrl = "http://34.85.38.141/";

    Bitmap bitmap1, bitmap2, bitmap3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        TextView nameText = (TextView) findViewById(R.id.textView_name);
        TextView sexText = (TextView) findViewById(R.id.textView_sex);
        TextView ageText = (TextView) findViewById(R.id.textView_age);
        TextView chartText = (TextView) findViewById(R.id.textView_chart);
        TextView handText = (TextView) findViewById(R.id.textView_hand);
        TextView stateText = (TextView) findViewById(R.id.textView_state);
        TextView etcText = (TextView) findViewById(R.id.textView_etc);
        ViewPager viewpager = (ViewPager) findViewById(R.id.viewPager);
        Intent intent = getIntent();

        img1 = intent.getStringExtra("img1");
        img2 = intent.getStringExtra("img2");
        img3 = intent.getStringExtra("img3");


        imgLoad1 firstImg = new imgLoad1();
        firstImg.start();
        try {
            firstImg.join();
        } catch (Exception e) {
            e.printStackTrace();
        }

        imgLoad2 secondImg = new imgLoad2();
        secondImg.start();
        try {
            secondImg.join();
        } catch (Exception e) {
            e.printStackTrace();
        }

        imgLoad3 thirdImg = new imgLoad3();
        thirdImg.start();
        try {
            thirdImg.join();
        } catch (Exception e) {
            e.printStackTrace();
        }

        ViewPagerAdapter adapter = new ViewPagerAdapter(this);
        viewpager.setAdapter(adapter);

        String name = intent.getStringExtra("name");
        String sex = intent.getStringExtra("sex");
        String age = intent.getStringExtra("age");
        String handling = intent.getStringExtra("handling");
        String chart = intent.getStringExtra("chart");
        String desexualize = intent.getStringExtra("desexualize");
        String state = intent.getStringExtra("state");
        String etc = intent.getStringExtra("etc");

        nameText.setText(name);
        sexText.setText(sex + ", 중성화수술 : " + desexualize);
        ageText.setText(age);
        chartText.setText(chart);
        handText.setText(handling);
        stateText.setText(state);
        etcText.setText(etc);
    }

    public class ViewPagerAdapter extends PagerAdapter {

        private Context context;
        private LayoutInflater layoutInflater;
        Bitmap[] items = {bitmap1, bitmap2, bitmap3};

        public ViewPagerAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return items.length;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == o;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = layoutInflater.inflate(R.layout.custom_layout, null);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            imageView.setImageBitmap(items[position]);

            ViewPager vp = (ViewPager) container;
            vp.addView(view, 0);
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            ViewPager vp = (ViewPager) container;
            View view = (View) object;
            vp.removeView(view);
        }
    }

    class imgLoad1 extends Thread {
        String str = imgUrl + img1;

        public void run() {
            try {
                URL url = new URL(str);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.connect();

                InputStream is = conn.getInputStream();
                bitmap1 = BitmapFactory.decodeStream(is);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class imgLoad2 extends Thread {
        String str = imgUrl + img2;

        public void run() {
            try {
                URL url = new URL(str);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.connect();

                InputStream is = conn.getInputStream();
                bitmap2 = BitmapFactory.decodeStream(is);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class imgLoad3 extends Thread {
        String str = imgUrl + img3;

        public void run() {
            try {
                URL url = new URL(str);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.connect();

                InputStream is = conn.getInputStream();
                bitmap3 = BitmapFactory.decodeStream(is);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
