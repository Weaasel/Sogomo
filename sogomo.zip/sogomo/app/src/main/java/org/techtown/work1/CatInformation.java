package org.techtown.work1;

import android.graphics.Bitmap;

public class CatInformation {

    private String[] CatData;

    public CatInformation(String name, String sex, String age, String handling, String desexualize, String state
            , String chart, String etc, String img1, String img2, String img3) {
        CatData = new String[11];
        CatData[0] = name;
        CatData[1] = sex;
        CatData[2] = age;
        CatData[3] = handling;
        CatData[4] = desexualize;
        CatData[5] = state;
        CatData[6] = chart;
        CatData[7] = etc;
        CatData[8] = img1;
        CatData[9] = img2;
        CatData[10] = img3;

        //CatData[8] = bitmapfile.toString();
    }

    public String[] getCatData() {
        return CatData;
    }

    public void setCatData(String[] catData) {
        CatData = catData;
    }

    public String getData(int index) {
        return CatData[index];
    }

}