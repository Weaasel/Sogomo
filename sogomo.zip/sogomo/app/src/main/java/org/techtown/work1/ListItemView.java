package org.techtown.work1;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.text.method.ScrollingMovementMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ListItemView extends LinearLayout {

    private static String IP_ADDRESS = "34.85.38.141";
    private static String TAG = "Work1";

    TextView writertext;
    TextView foodtext;
    TextView watertext;
    TextView timetext;
    TextView daytext;
    TextView weathertext;
    TextView extratext;
    RelativeLayout container;
    ImageButton exit;
    Button morebutton;
    TextView idtext;
    TextView fctext;
    RelativeLayout relativeLayout;

    public ListItemView(Context context) {
        super(context);

        init(context);
    }

    public ListItemView(Context context, AttributeSet attrs) {
        super(context, attrs);

        init(context);
    }

    public void init(Context context){
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.list_item,this,true);
        writertext=(TextView)findViewById(R.id.writertext);
        foodtext=(TextView)findViewById(R.id.foodtext);
        watertext=(TextView)findViewById(R.id.watertext);
        timetext=(TextView)findViewById(R.id.timetext);
        daytext=(TextView)findViewById(R.id.daytext);
        weathertext=(TextView)findViewById(R.id.weathertext);
        extratext=(TextView)findViewById(R.id.moretext);
        idtext=(TextView)findViewById(R.id.idtext);
        container=(RelativeLayout)findViewById(R.id.morebox);
        exit=(ImageButton)findViewById(R.id.imageButton);
        morebutton=(Button)findViewById(R.id.more);
        relativeLayout=(RelativeLayout)findViewById(R.id.relativeLayout);
        fctext=(TextView)findViewById(R.id.fctext);
        morebutton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                container.setVisibility(View.VISIBLE);
            }
        });
        exit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                container.setVisibility(View.INVISIBLE);
            }
        });

        relativeLayout.setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                AlertDialog.Builder alert = new AlertDialog.Builder(getContext());
                alert.setMessage("선택");
                alert.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                        builder.setMessage("정말 삭제하시겠습니까?");
                        builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String id_sql = (String)idtext.getText();

                                //여기다가 삭제구현
                                ListItemView.InsertData task = new ListItemView.InsertData();
                                task.execute("http://" + IP_ADDRESS + "/php_final/delete.php", id_sql);
                                String fc=(String)fctext.getText();
                                Intent intent = new Intent(getContext(),temp.class);
                                intent.putExtra("locate",fc);
                                getContext().startActivity(intent);

                            }
                        });
                        builder.show();
                    }
                });
                alert.setNegativeButton("수정", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String str = (String)idtext.getText();
                        Intent intent = new Intent(getContext(),EnrollTable_Edit.class);
                        intent.putExtra("id",str);
                        getContext().startActivity(intent);
                    }
                });
                alert.show();
                return false;
            }
        });



    }
    class InsertData extends AsyncTask<String, Void, String> {
        ProgressDialog progressDialog;

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

           // progressDialog.dismiss();
            Toast.makeText(getContext(), result, Toast.LENGTH_LONG).show();
            Log.d(TAG, "POST response  - " + result);
        }

        @Override
        protected String doInBackground(String... params) {

            String id_sql = (String)params[1];


            // 1. PHP 파일을 실행시킬 수 있는 주소와 전송할 데이터를 준비합니다.
            // POST 방식으로 데이터 전달시에는 데이터가 주소에 직접 입력되지 않습니다.
            String serverURL = (String)params[0];

            // HTTP 메시지 본문에 포함되어 전송되기 때문에 따로 데이터를 준비해야 합니다.
            // 전송할 데이터는 “이름=값” 형식이며 여러 개를 보내야 할 경우에는 항목 사이에 &를 추가합니다.
            // 여기에 적어준 이름을 나중에 PHP에서 사용하여 값을 얻게 됩니다.
            String postParameters = "id_sql=" + id_sql;


            try {
                // 2. HttpURLConnection 클래스를 사용하여 POST 방식으로 데이터를 전송합니다.
                URL url = new URL(serverURL); // 주소가 저장된 변수를 이곳에 입력합니다.
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000); //5초안에 응답안오면 예외발생
                httpURLConnection.setConnectTimeout(5000); //5초안에 연결안되면 예외발생
                httpURLConnection.setRequestMethod("POST"); //요청방식은 POST로
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();

                //전송할 데이터가 저장된 변수를 이곳에 입력합니다. 인코딩을 고려해줘야 합니다.
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                //응답읽기
                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    //정상적인 응답데이터
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    //에러발생
                    inputStream = httpURLConnection.getErrorStream();
                }

                // 4. StringBuilder를 사용하여 수신되는 데이터를 저장합니다.
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();

                // 5. 저장된 데이터를 스트링으로 변환하여 리턴합니다.
                return sb.toString();

            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }
    public void setWriter(String writer){
        writertext.setText(writer);
    }
    public void setFood(String food){
        foodtext.setText(food);
    }
    public void setWater(String water){
        watertext.setText(water);
    }
    public void setTime(String time){
        timetext.setText(time);
    }
    public void setWeather(String weather){
        weathertext.setText(weather);
    }
    public void setDay(String day){daytext.setText(day);}
    public void settext(String extrainformation){extratext.setText(extrainformation);}
    public void setId(String id){idtext.setText(id);}
    public void setFc(String fc){fctext.setText(fc);}

}