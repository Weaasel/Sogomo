package org.techtown.work1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class temp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);

        Intent intent = getIntent();
        String locate=intent.getStringExtra("locate");
        if(locate.equals("1")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","J관");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("2")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","K관");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("3")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","D관");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("4")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","X관");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("5")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","Tomo관");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("6")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","GA관");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("7")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","곤쓰");
            startActivity(intent1);
            finish();
        }
        else if(locate.equals("8")){
            Intent intent1 = new Intent(getApplicationContext(),List.class);
            intent1.putExtra("locate","알탑");
            startActivity(intent1);
            finish();
        }
    }
}
