package org.techtown.work1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

public class CatAdapter extends BaseAdapter {
    ArrayList<CatItem> items = new ArrayList<CatItem>();

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addItem(CatItem item){
        items.add(item);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Context context = parent.getContext();
        CatItemView view = new CatItemView(context);
        CatItem item = items.get(position);
        view.setImageView(item.bitmap);
        view.setName(item.getName());

        return view;
    }
}
