package org.techtown.work1;


import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class EnrollTable extends AppCompatActivity {

    private static String IP_ADDRESS = "34.85.38.141";
    private static String TAG = "Work1";

    //mysql넘기는 변수
    String food_sql = "0%";
    String water_sql = "0%";
    String weather_sql;
    String note_sql;
    String manager_sql;
    String time_sql = "99";
    String fc_sql;
    //현재 시간
    long curTime = System.currentTimeMillis();
    Date timeData = new Date(curTime);
    SimpleDateFormat timeDataFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat timeDataFormat2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat timeDataFormat3 = new SimpleDateFormat("HH:mm:ss");

    String timeString = timeDataFormat.format(timeData);
    String day_sql = timeDataFormat2.format(timeData);
    String curTime2 = timeDataFormat3.format(timeData);

    String time1 = "09:00:00";
    String time2 = "13:30:00";
    String time3 = "18:00:00";

    Date time11;
    Date time22;
    Date time33;
    Date currentTime;

    {
        try {
            time11 = timeDataFormat3.parse(time1);
            time22 = timeDataFormat3.parse(time2);
            time33 = timeDataFormat3.parse(time3);
            currentTime = timeDataFormat3.parse(curTime2);

            if(currentTime.before(time11)) time_sql = "1";
            if(currentTime.after(time11) && currentTime.before(time22)) time_sql = "2";
            if(currentTime.after(time22) && currentTime.before(time33)) time_sql = "3";
            else time_sql ="4";

        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    TextView textView;

    //급식소 장소 스피너
    Spinner location;
    String[] items = {"정하상관","김대건관","다산관","하비에르관","토마스모어관","가브리엘관","곤자가쓰레기장","알바트로스탑"};
    String[] items_num = {"1","2","3","4","5","6","7","8"};

    //사료, 물량 체크
    SeekBar food;
    SeekBar water;
    TextView food_p;
    TextView water_p;

    //날씨, 담당자, 특이사항 + 등록 버튼

    Button enroll;
    EditText weather;
    EditText manager;
    EditText note;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enroll_table);


        textView = (TextView) findViewById(R.id.textView);
        textView.setText(timeString);

        weather = (EditText) findViewById(R.id.editText3);
        manager = (EditText) findViewById(R.id.editText);
        note = (EditText) findViewById(R.id.editText2);

        //급식소 장소
        location = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, items
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        location.setAdapter(adapter);

        location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                fc_sql = items_num[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        food_p = (TextView) findViewById(R.id.textView11);
        water_p =(TextView) findViewById(R.id.textView12);

        food = (SeekBar) findViewById(R.id.seekBar3);
        food.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                food_p.setText(String.valueOf(progress)+"%");
                food_sql =String.valueOf(progress)+"%";

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        water = (SeekBar) findViewById(R.id.seekBar4);
        water.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                water_p.setText(String.valueOf(progress)+"%");
                water_sql = String.valueOf(progress)+"%";

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //날씨, 담당자, 특이사항 객체 문자열로 변환
        enroll = (Button) findViewById(R.id.button_check);

        enroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                weather_sql = weather.getText().toString();
                manager_sql = manager.getText().toString();
                note_sql = note.getText().toString();



                InsertData task = new InsertData();
                task.execute("http://" + IP_ADDRESS + "/php_final/insert.php", food_sql,water_sql, weather_sql, note_sql, manager_sql, day_sql, time_sql, fc_sql);

                if(!(manager_sql.equals("")) && !(weather_sql.equals(""))) finish();

            }
        });

    }



    @Override
    public void onBackPressed(){
        AlertDialog.Builder builder = new AlertDialog.Builder (this);
        builder.setMessage("작성을 취소하시겠습니까?");
        builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
        //super.onBackPressed();
    }

    class InsertData extends AsyncTask<String, Void, String>{
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(EnrollTable.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
            Log.d(TAG, "POST response  - " + result);
        }



        @Override
        protected String doInBackground(String... params) {

            String food_sql = (String)params[1];
            String water_sql = (String)params[2];
            String weather_sql = (String)params[3];
            String note_sql = (String)params[4];
            String manager_sql = (String)params[5];
            String day_sql = (String)params[6];
            String time_sql = (String)params[7];
            String fc_sql = (String)params[8];


            // 1. PHP 파일을 실행시킬 수 있는 주소와 전송할 데이터를 준비합니다.
            // POST 방식으로 데이터 전달시에는 데이터가 주소에 직접 입력되지 않습니다.
            String serverURL = (String)params[0];

            // HTTP 메시지 본문에 포함되어 전송되기 때문에 따로 데이터를 준비해야 합니다.
            // 전송할 데이터는 “이름=값” 형식이며 여러 개를 보내야 할 경우에는 항목 사이에 &를 추가합니다.
            // 여기에 적어준 이름을 나중에 PHP에서 사용하여 값을 얻게 됩니다.
            String postParameters = "food_sql=" + food_sql + "&water_sql=" + water_sql+ "&weather_sql=" + weather_sql+ "&note_sql=" + note_sql+ "&manager_sql=" + manager_sql+ "&day_sql=" + day_sql+ "&time_sql=" + time_sql+ "&fc_sql=" + fc_sql;


            try {
                // 2. HttpURLConnection 클래스를 사용하여 POST 방식으로 데이터를 전송합니다.
                URL url = new URL(serverURL); // 주소가 저장된 변수를 이곳에 입력합니다.
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000); //5초안에 응답안오면 예외발생
                httpURLConnection.setConnectTimeout(5000); //5초안에 연결안되면 예외발생
                httpURLConnection.setRequestMethod("POST"); //요청방식은 POST로
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();

                //전송할 데이터가 저장된 변수를 이곳에 입력합니다. 인코딩을 고려해줘야 합니다.
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();

                //응답읽기
                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "POST response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    //정상적인 응답데이터
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    //에러발생
                    inputStream = httpURLConnection.getErrorStream();
                }

                // 4. StringBuilder를 사용하여 수신되는 데이터를 저장합니다.
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line = null;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }


                bufferedReader.close();

                // 5. 저장된 데이터를 스트링으로 변환하여 리턴합니다.
                return sb.toString();

            } catch (Exception e) {

                Log.d(TAG, "InsertData: Error ", e);

                return new String("Error: " + e.getMessage());
            }

        }
    }

}